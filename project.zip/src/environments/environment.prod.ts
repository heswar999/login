export const environment = {
  production: true,
  baseUrl: "https://9a5788dc-802c-4e34-8b84-31ca09d287c2.mock.pstmn.io"
};
