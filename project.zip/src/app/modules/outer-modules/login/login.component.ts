import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountService } from '../../../services/account-service/account.service';
import { LocalStorageService } from '../../../services/localstorage-service/localStorage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: any = {};
  submitted: boolean = false;
  isLoaderShow: boolean = false;
  constructor(private _fb: FormBuilder,
    private _accountService: AccountService,
    private _localStorageService: LocalStorageService,
    private _router: Router) {
  }
  ngOnInit(): void {
    this.loginForm = this._fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
    })
  }
  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.loginAPICall(this.loginForm.value);
  }
  loginAPICall(loginModel: any = {}) {
    this.isLoaderShow = true;
    this._accountService.login(loginModel).subscribe(res => {
      let result: any = res;
      this.isLoaderShow = false;
      if (result.error) {
        alert(result.message)
        //show some error message
      } else {
        this._localStorageService.removeAll();
        this._localStorageService.saveuser(result.data);
        this._localStorageService.savetoken(result.token, () => {
          this._router.navigate(["dashboard"]);
        });
      }
    }, err => {
      this.isLoaderShow = false;
    })
  }
  get f() {
    return this.loginForm.controls
  }
}
