import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LocalStorageService } from '../../../services/localstorage-service/localStorage.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private _localStorageService: LocalStorageService,
    private _router: Router) { }

  ngOnInit(): void {
  }

  logOut() {
    this._localStorageService.removeAll();
    this._router.navigate(["login"]);
  }

}
