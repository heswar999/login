import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './modules/inner-modules/dashboard/dashboard.component';
import { LoginComponent } from './modules/outer-modules/login/login.component';
import { AuthGuardService } from './services/auth-gaurd-service/auth-guard.service';
import { AuthLoginGuardService } from './services/auth-gaurd-service/auth-login-guard.service ';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {
    path: 'login',
    component: LoginComponent,
    canActivate: [AuthLoginGuardService],
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuardService],
  },

  { path: '**', redirectTo: '', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
