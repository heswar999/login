import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {
  constructor(private route: Router) {
  }
  saveuser(User: any) {
    localStorage.setItem("user_", JSON.stringify(User));
  }
  savetoken(token: any, callback: any) {
    localStorage.setItem("token_", token);
    if (callback) { callback() }
  }
  removeAll() {
    localStorage.clear();
  }
  getToken() {
    return localStorage.getItem("token_")
    
  }

}
