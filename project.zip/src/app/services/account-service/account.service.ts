import { Injectable } from '@angular/core';
import { APIEndPointPath } from '../http.service/api.service.path';
import { HttpService } from '../http.service/httpService';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private _httpService: HttpService) { }


  login(loginPayload: any = {}) {
    return this._httpService.post(APIEndPointPath.login, loginPayload);
  }
}
