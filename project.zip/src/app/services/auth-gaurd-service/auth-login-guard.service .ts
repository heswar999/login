import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { LocalStorageService } from '../localstorage-service/localStorage.service';
@Injectable({
  providedIn: 'root'
})
export class AuthLoginGuardService implements CanActivate {
  constructor(private _localStorageService: LocalStorageService,
    private _router: Router, ) { }
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const token = this._localStorageService.getToken();
    if (token) {
      this._router.navigate(["dashboard"]);
      return false;
    } else {
      return true;
    }
  }
}
