import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class HttpService {

  baseUrl: string

  constructor(private http: HttpClient) {
    this.baseUrl = environment.baseUrl;
  }
  post(url: string, data: object = {}) {
    return this.http.post<any>(`${this.baseUrl}/${url}`, data)
      .pipe(map(response => {
        return response;
      }));
  }
  get(url: string) {
    return this.http.get<any>(`${this.baseUrl}/${url}`)
      .pipe(map(response => {
        return response;
      }));
  }
  put(url: string, data: object = {}) {
    return this.http.put<any>(`${this.baseUrl}/${url}`, data)
      .pipe(map(response => {
        return response;
      }));
  }
  delete(url: string, loading: boolean = false) {
    return this.http.delete<any>(`${this.baseUrl}/${url}`)
      .pipe(map(response => {
        return response;
      }));
  }
}
