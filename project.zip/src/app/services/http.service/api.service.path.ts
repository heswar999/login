
export const APIEndPointPath = {
  login: 'v1/Login',
 

}
